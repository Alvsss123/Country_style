# fix_usuarios.py
import os
import django

# Configura o Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'country_style.settings')
django.setup()

from django.contrib.auth.models import User

def corrigir_usuarios():
    """Corrige emails e usernames para minúsculas e sem espaços"""
    print("=" * 50)
    print("INICIANDO CORREÇÃO DE USUÁRIOS...")
    print("=" * 50)
    
    usuarios_corrigidos = 0
    
    for user in User.objects.all():
        alterado = False
        
        # Corrigir email
        if user.email:
            email_correto = user.email.lower().strip()
            if user.email != email_correto:
                print(f"Email corrigido: '{user.email}' -> '{email_correto}'")
                user.email = email_correto
                alterado = True
        
        # Corrigir username (deve ser igual ao email)
        if user.username != user.email:
            print(f"Username corrigido: '{user.username}' -> '{user.email}'")
            user.username = user.email
            alterado = True
        
        if alterado:
            user.save()
            usuarios_corrigidos += 1
    
    print("=" * 50)
    print(f"Correção concluída! {usuarios_corrigidos} usuário(s) corrigido(s).")
    print("=" * 50)

def listar_usuarios():
    """Lista todos os usuários para verificação"""
    print("\nLISTA DE USUÁRIOS:")
    print("-" * 50)
    for user in User.objects.all():
        print(f"ID: {user.id} | Username: {user.username} | Email: {user.email} | Nome: {user.first_name}")
    print("-" * 50)

if __name__ == '__main__':
    print("\n1. Listar usuários")
    print("2. Corrigir usuários")
    print("3. Sair")
    
    opcao = input("\nEscolha uma opção (1-3): ")
    
    if opcao == '1':
        listar_usuarios()
    elif opcao == '2':
        corrigir_usuarios()
    else:
        print("Saindo...")