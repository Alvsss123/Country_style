from django.contrib.auth.models import User
from django.db import models
from django.core.validators import RegexValidator, EmailValidator, MinLengthValidator
from loja.models import Produto, Categoria, Cliente, ItemSacola 
class Categoria(models.Model):
    nome = models.CharField(max_length=50)
    slug = models.SlugField(unique=True)
    
    def __str__(self):
        return self.nome

class Produto(models.Model):
    nome = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    descricao = models.TextField()
    preco = models.DecimalField(max_digits=10, decimal_places=2)
    preco_promocional = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    imagem = models.ImageField(upload_to='produtos/', blank=True, null=True)
    categoria = models.ForeignKey(Categoria, on_delete=models.SET_NULL, null=True)
    disponivel = models.BooleanField(default=True)
    data_criacao = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.nome
    
    @property
    def preco_atual(self):
        return self.preco_promocional if self.preco_promocional else self.preco

class ItemSacola(models.Model):
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE)
    quantidade = models.IntegerField(default=1)
    tamanho = models.CharField(max_length=10, blank=True)
    sessao_id = models.CharField(max_length=100)
    data_adicao = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.quantidade}x {self.produto.nome}"
    
    @property
    def subtotal(self):
        return self.produto.preco_atual * self.quantidade


# ==================== MODELOS PARA PEDIDOS (FASE 3) ====================

class Pedido(models.Model):
    STATUS_CHOICES = [
        ('aguardando', 'Aguardando pagamento'),
        ('pago', 'Pago'),
        ('preparando', 'Em preparação'),
        ('enviado', 'Enviado'),
        ('entregue', 'Entregue'),
        ('cancelado', 'Cancelado'),
    ]
    
    cliente = models.ForeignKey(Cliente, on_delete=models.SET_NULL, null=True)
    data_pedido = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='aguardando')
    total = models.DecimalField(max_digits=10, decimal_places=2)
    endereco_entrega = models.TextField()
    
    def __str__(self):
        return f"Pedido #{self.id} - {self.cliente.nome if self.cliente else 'Cliente'}"

class ItemPedido(models.Model):
    pedido = models.ForeignKey(Pedido, on_delete=models.CASCADE, related_name='itens')
    produto = models.ForeignKey(Produto, on_delete=models.SET_NULL, null=True)
    quantidade = models.IntegerField()
    preco_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    tamanho = models.CharField(max_length=10, blank=True)
    
    def subtotal(self):
        return self.preco_unitario * self.quantidade