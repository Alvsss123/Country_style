from django.shortcuts import render,  get_object_or_404, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.db.models import Sum, Count
from loja.models import Produto, Categoria, Cliente, ItemSacola
from django.contrib.auth.models import User
from decimal import Decimal
import re
from django.core.paginator import Paginator
# ==================== VERIFICAÇÃO DE GERENTE ====================

def is_gerente(user):
    """Verifica se o usuário é gerente ou superuser"""
    return user.is_authenticated and (user.is_superuser or user.groups.filter(name='Gerentes').exists())

# ==================== DASHBOARD ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def dashboard(request):
    """Dashboard da gerência"""
    context = {
        'total_produtos': Produto.objects.count(),
        'total_clientes': Cliente.objects.count() if 'Cliente' in globals() else 0,
        'total_pedidos': ItemSacola.objects.count() if 'ItemSacola' in globals() else 0,
        'total_categorias': Categoria.objects.count(),
    }
    return render(request, 'gestao/dashboard.html', context)

# ==================== GESTÃO DE PRODUTOS ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def produto_list(request):
    """Lista todos os produtos com paginação"""
    produtos_list = Produto.objects.all().order_by('-data_criacao')
    
    # Paginação: 10 produtos por página
    paginator = Paginator(produtos_list, 10)
    page_number = request.GET.get('page')
    produtos = paginator.get_page(page_number)
    
    return render(request, 'gestao/produto_list.html', {
        'produtos': produtos,
        'paginator': paginator
    })

# ==================== GESTÃO DE CLIENTES ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def cliente_list(request):
    """Lista todos os clientes com paginação"""
    clientes_list = Cliente.objects.all().order_by('-data_cadastro')
    
    # Paginação: 15 clientes por página
    paginator = Paginator(clientes_list, 15)
    page_number = request.GET.get('page')
    clientes = paginator.get_page(page_number)
    
    return render(request, 'gestao/cliente_list.html', {
        'clientes': clientes,
        'paginator': paginator
    })

# ==================== GESTÃO DE PEDIDOS ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def pedido_list(request):
    """Lista todos os pedidos com paginação"""
    pedidos_list = ItemSacola.objects.all().order_by('-data_adicao')
    
    # Paginação: 20 pedidos por página
    paginator = Paginator(pedidos_list, 20)
    page_number = request.GET.get('page')
    pedidos = paginator.get_page(page_number)
    
    return render(request, 'gestao/pedido_list.html', {
        'pedidos': pedidos,
        'paginator': paginator
    })

# ==================== RELATÓRIOS ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def relatorios(request):
    """Página de relatórios"""
    context = {
        'total_produtos': Produto.objects.count(),
        'total_clientes': Cliente.objects.count(),
        'total_pedidos': ItemSacola.objects.count(),
        'total_categorias': Categoria.objects.count(),
    }
    return render(request, 'gestao/relatorios.html', context)

#====================CADASTRO=================

def validar_telefone(telefone):
    """Valida telefone no formato (11) 99999-9999"""
    padrao = r'^\([1-9]{2}\) [9]?[0-9]{4}-[0-9]{4}$'
    return re.match(padrao, telefone) is not None

def cadastro(request):
    if request.method == 'POST':
        nome = request.POST.get('nome')
        telefone = request.POST.get('telefone')
        email = request.POST.get('email')
        senha = request.POST.get('senha')
        confirma_senha = request.POST.get('confirma_senha')
        
        # Validações
        if not nome or len(nome) < 3:
            messages.error(request, 'O nome deve ter pelo menos 3 caracteres')
            return render(request, 'cadastro.html')
        
        if not re.match(r'^[A-Za-zÀ-ÿ\s]+$', nome):
            messages.error(request, 'O nome deve conter apenas letras')
            return render(request, 'cadastro.html')
        
        if not validar_telefone(telefone):
            messages.error(request, 'Telefone inválido. Use formato (11) 99999-9999')
            return render(request, 'cadastro.html')
        
        if senha != confirma_senha:
            messages.error(request, 'As senhas não coincidem')
            return render(request, 'cadastro.html')
        
        if len(senha) < 6:
            messages.error(request, 'A senha deve ter pelo menos 6 caracteres')
            return render(request, 'cadastro.html')
        
        if User.objects.filter(username=email).exists():
            messages.error(request, 'Este e-mail já está cadastrado')
            return render(request, 'cadastro.html')