from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.core.paginator import Paginator
from loja.models import Produto, Categoria, Cliente, ItemSacola
from decimal import Decimal

# ==================== VERIFICAÇÃO DE GERENTE ====================

def is_gerente(user):
    """Verifica se o usuário é gerente ou superuser"""
    return user.is_authenticated and (user.is_superuser or user.groups.filter(name='Gerentes').exists())

# ==================== DASHBOARD ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def dashboard(request):
    """Dashboard da gerência"""
    context = {
        'total_produtos': Produto.objects.count(),
        'total_clientes': Cliente.objects.count(),
        'total_pedidos': ItemSacola.objects.count(),
        'total_categorias': Categoria.objects.count(),
    }
    return render(request, 'gestao/dashboard.html', context)

# ==================== GESTÃO DE PRODUTOS ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def produto_list(request):
    """Lista todos os produtos com paginação"""
    produtos_list = Produto.objects.all().order_by('-data_criacao')
    paginator = Paginator(produtos_list, 10)
    page_number = request.GET.get('page')
    produtos = paginator.get_page(page_number)
    return render(request, 'gestao/produto_list.html', {'produtos': produtos})

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def produto_create(request): 
    """Cria um novo produto"""
    if request.method == 'POST':
        try:
            produto = Produto.objects.create(
                nome=request.POST.get('nome'),
                slug=request.POST.get('slug'),
                descricao=request.POST.get('descricao'),
                preco=Decimal(request.POST.get('preco')),
                preco_promocional=Decimal(request.POST.get('preco_promocional')) if request.POST.get('preco_promocional') else None,
                categoria_id=request.POST.get('categoria'),
                disponivel=request.POST.get('disponivel') == 'on',
            )
            
            if 'imagem' in request.FILES:
                produto.imagem = request.FILES['imagem']
                produto.save()
            
            messages.success(request, 'Produto criado com sucesso!')
            return redirect('gestao:produto_list')
        except Exception as e:
            messages.error(request, f'Erro ao criar produto: {str(e)}')
    
    categorias = Categoria.objects.all()
    return render(request, 'gestao/produto_form.html', {
        'categorias': categorias,
        'is_edit': False
    })

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def produto_update(request, pk):
    """Edita um produto existente"""
    produto = get_object_or_404(Produto, pk=pk)
    
    if request.method == 'POST':
        try:
            produto.nome = request.POST.get('nome')
            produto.slug = request.POST.get('slug')
            produto.descricao = request.POST.get('descricao')
            produto.preco = Decimal(request.POST.get('preco'))
            produto.preco_promocional = Decimal(request.POST.get('preco_promocional')) if request.POST.get('preco_promocional') else None
            produto.categoria_id = request.POST.get('categoria')
            produto.disponivel = request.POST.get('disponivel') == 'on'
            
            if 'imagem' in request.FILES:
                produto.imagem = request.FILES['imagem']
            
            produto.save()
            messages.success(request, 'Produto atualizado com sucesso!')
            return redirect('gestao:produto_list')
        except Exception as e:
            messages.error(request, f'Erro ao atualizar produto: {str(e)}')
    
    categorias = Categoria.objects.all()
    return render(request, 'gestao/produto_form.html', {
        'produto': produto,
        'categorias': categorias,
        'is_edit': True
    })

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def produto_delete(request, pk):
    """Remove um produto"""
    produto = get_object_or_404(Produto, pk=pk)
    
    if request.method == 'POST':
        produto.delete()
        messages.success(request, 'Produto removido com sucesso!')
        return redirect('gestao:produto_list')
    
    return render(request, 'gestao/produto_confirm_delete.html', {'produto': produto})

# ==================== GESTÃO DE CLIENTES ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def cliente_list(request):
    """Lista todos os clientes com paginação"""
    clientes_list = Cliente.objects.all().order_by('-data_cadastro')
    paginator = Paginator(clientes_list, 15)
    page_number = request.GET.get('page')
    clientes = paginator.get_page(page_number)
    return render(request, 'gestao/cliente_list.html', {'clientes': clientes})

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def cliente_detail(request, pk):
    """Detalhes de um cliente"""
    cliente = get_object_or_404(Cliente, pk=pk)
    return render(request, 'gestao/cliente_detail.html', {'cliente': cliente})

# ==================== GESTÃO DE PEDIDOS ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def pedido_list(request):
    """Lista todos os pedidos com paginação"""
    pedidos_list = ItemSacola.objects.all().order_by('-data_adicao')
    paginator = Paginator(pedidos_list, 20)
    page_number = request.GET.get('page')
    pedidos = paginator.get_page(page_number)
    return render(request, 'gestao/pedido_list.html', {'pedidos': pedidos})

# ==================== RELATÓRIOS ====================

@login_required
@user_passes_test(is_gerente, login_url='/', redirect_field_name=None)
def relatorios(request):
    """Página de relatórios"""
    context = {
        'total_produtos': Produto.objects.count(),
        'total_clientes': Cliente.objects.count(),
        'total_pedidos': ItemSacola.objects.count(),
        'total_categorias': Categoria.objects.count(),
    }
    return render(request, 'gestao/relatorios.html', context)