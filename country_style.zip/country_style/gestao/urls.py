from django.urls import path
from . import views

app_name = 'gestao'

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    
    # Produtos
    path('produtos/', views.produto_list, name='produto_list'),
    path('produtos/novo/', views.produto_create, name='produto_create'),
    path('produtos/<int:pk>/editar/', views.produto_update, name='produto_update'),
    path('produtos/<int:pk>/deletar/', views.produto_delete, name='produto_delete'),
    
    # Clientes
    path('clientes/', views.cliente_list, name='cliente_list'),
    path('clientes/<int:pk>/', views.cliente_detail, name='cliente_detail'),
    
    # Pedidos
    path('pedidos/', views.pedido_list, name='pedido_list'),
    
    # Relatórios
    path('relatorios/', views.relatorios, name='relatorios'),
]