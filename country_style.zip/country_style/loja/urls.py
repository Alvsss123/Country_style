from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('cadastro/', views.cadastro, name='cadastro'),
    path('login/', views.login, name='login'),
    path('produto/<int:produto_id>/', views.produto, name='produto'),
    path('sacola/', views.sacola, name='sacola'),
    path('cadastrar/', views.cadastrar_cliente, name='cadastrar_cliente'),
    path('adicionar-sacola/<int:produto_id>/', views.adicionar_sacola, name='adicionar_sacola'),
     path('remover-sacola/<int:item_id>/', views.remover_sacola, name='remover_sacola'),
    path('api/contador-sacola/', views.contador_sacola, name='contador_sacola'),
    path('api/totais-sacola/', views.totais_sacola, name='totais_sacola'),
]