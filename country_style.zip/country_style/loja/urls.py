from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('cadastro/', views.cadastro, name='cadastro'),
    path('login/', views.login_view, name='login'),  
    path('logout/', views.logout_view, name='logout'),  
    path('produto/<int:produto_id>/', views.produto, name='produto'),
    path('sacola/', views.sacola, name='sacola'),
    path('cadastrar/', views.cadastrar_cliente, name='cadastrar_cliente'),
    path('adicionar-sacola/<int:produto_id>/', views.adicionar_sacola, name='adicionar_sacola'),
    path('remover-sacola/<int:item_id>/', views.remover_sacola, name='remover_sacola'),
    path('api/contador-sacola/', views.contador_sacola, name='contador_sacola'),
    path('api/totais-sacola/', views.totais_sacola, name='totais_sacola'),
    path('checkout/', views.checkout, name='checkout'),  
    path('finalizar-pedido/', views.finalizar_pedido, name='finalizar_pedido'),
    path('perfil/', views.perfil, name='perfil'),
    path('atualizar-perfil/', views.atualizar_perfil, name='atualizar_perfil'),
    path('alterar-senha/', views.alterar_senha, name='alterar_senha'),
    path('categoria/<slug:categoria_slug>/', views.produtos_por_categoria, name='categoria'),
    path('busca/', views.busca, name='busca'), 
]