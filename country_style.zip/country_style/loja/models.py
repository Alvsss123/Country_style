from django.contrib.auth.models import User
from django.db import models
from django.core.validators import RegexValidator, EmailValidator, MinLengthValidator
import re

class Categoria(models.Model):
    nome = models.CharField(max_length=50)
    slug = models.SlugField(unique=True)
    
    def __str__(self):
        return self.nome

class Produto(models.Model):
    nome = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    descricao = models.TextField()
    preco = models.DecimalField(max_digits=10, decimal_places=2)
    preco_promocional = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    imagem = models.ImageField(upload_to='produtos/', blank=True, null=True)
    categoria = models.ForeignKey(Categoria, on_delete=models.SET_NULL, null=True)
    disponivel = models.BooleanField(default=True)
    data_criacao = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.nome
    
    @property
    def preco_atual(self):
        return self.preco_promocional if self.preco_promocional else self.preco

class ItemSacola(models.Model):
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE)
    quantidade = models.IntegerField(default=1)
    tamanho = models.CharField(max_length=10, blank=True)
    sessao_id = models.CharField(max_length=100)  # Para identificar a sacola do usuário
    data_adicao = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.quantidade}x {self.produto.nome}"
    
    @property
    def subtotal(self):
        return self.produto.preco_atual * self.quantidade
    
# Clientes

class Cliente(models.Model):
    usuario = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    
    # Validação de nome (mínimo 3 caracteres, apenas letras)
    nome = models.CharField(
        max_length=100,
        validators=[
            MinLengthValidator(3, 'O nome deve ter pelo menos 3 caracteres'),
            RegexValidator(r'^[a-zA-ZÀ-ÿ\s]+$', 'O nome deve conter apenas letras')
        ]
    )
    
    # Validação de telefone (formato brasileiro)
    telefone = models.CharField(
        max_length=20,
        validators=[
            RegexValidator(
                r'^\(?[1-9]{2}\)? ?9?[0-9]{4}-?[0-9]{4}$',
                'Telefone inválido. Use formato (11) 99999-9999'
            )
        ]
    )
    
    # Validação de email
    email = models.EmailField(
        unique=True,
        validators=[EmailValidator('E-mail inválido')]
    )
    
    data_cadastro = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.nome
    
#avaliacoes

class Avaliacao(models.Model):
    produto = models.ForeignKey(Produto, on_delete=models.CASCADE, related_name='avaliacoes')
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    nota = models.IntegerField(choices=[(i, i) for i in range(1, 6)])  # 1 a 5 estrelas
    comentario = models.TextField(blank=True)
    data = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['produto', 'usuario']  # Um usuário só avalia uma vez
    
    def __str__(self):
        return f"{self.usuario} - {self.produto} - {self.nota}★"