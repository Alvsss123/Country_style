from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login as auth_login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth import update_session_auth_hash
from .models import Produto, Categoria, ItemSacola, Cliente
from decimal import Decimal
from django.db.models import Q
from django.core.paginator import Paginator
 
# ==================== PÁGINAS PRINCIPAIS ====================

def index(request):
    """Página inicial com produtos do banco de dados"""
    produtos = Produto.objects.filter(disponivel=True).order_by('-data_criacao')[:6]
    return render(request, 'index.html', {'produtos': produtos})

def produto(request, produto_id):
    """Página de detalhe do produto"""
    produto = get_object_or_404(Produto, id=produto_id, disponivel=True)
    
    # Produtos da mesma categoria (relacionados)
    relacionados = Produto.objects.filter(
        categoria=produto.categoria, 
        disponivel=True
    ).exclude(id=produto.id)[:4]
    
    # Produtos mais vendidos (simulação - aleatório)
    mais_vendidos = Produto.objects.filter(disponivel=True).order_by('?')[:4]
    
    return render(request, 'produto.html', {
        'produto': produto,
        'relacionados': relacionados,
        'mais_vendidos': mais_vendidos
    })

def produtos_por_categoria(request, categoria_slug):
    categoria = get_object_or_404(Categoria, slug=categoria_slug)
    produtos_list = Produto.objects.filter(categoria=categoria, disponivel=True)
    
    paginator = Paginator(produtos_list, 9)  # 9 produtos por página
    page = request.GET.get('page')
    produtos = paginator.get_page(page)
    
    return render(request, 'categoria.html', {
        'categoria': categoria,
        'produtos': produtos
    })

# ==================== SACOLA ====================

def sacola(request):
    """Página da sacola de compras"""
    sessao_id = request.session.session_key
    if not sessao_id:
        request.session.create()
        sessao_id = request.session.session_key
    
    itens = ItemSacola.objects.filter(sessao_id=sessao_id)
    
    subtotal = sum(item.subtotal for item in itens)
    frete = Decimal('25.00') if subtotal > 0 else Decimal('0.00')
    total = subtotal + frete
    
    contexto = {
        'itens': itens,
        'subtotal': subtotal,
        'frete': frete,
        'total': total,
    }
    return render(request, 'sacola.html', contexto)

def adicionar_sacola(request, produto_id):
    """Adiciona um item à sacola via AJAX"""
    if request.method == 'POST':
        sessao_id = request.session.session_key
        if not sessao_id:
            request.session.create()
            sessao_id = request.session.session_key
        
        try:
            produto = get_object_or_404(Produto, id=produto_id, disponivel=True)
            tamanho = request.POST.get('tamanho', '')
            quantidade = int(request.POST.get('quantidade', 1))
            
            item, created = ItemSacola.objects.get_or_create(
                produto=produto,
                sessao_id=sessao_id,
                tamanho=tamanho,
                defaults={'quantidade': quantidade}
            )
            
            if not created:
                item.quantidade += quantidade
                item.save()
            
            total_itens = ItemSacola.objects.filter(sessao_id=sessao_id).count()
            
            return JsonResponse({
                'status': 'success',
                'message': 'Item adicionado à sacola!',
                'total_itens': total_itens
            })
            
        except Exception as e:
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            })
    
    return JsonResponse({'status': 'error', 'message': 'Método não permitido'})

def remover_sacola(request, item_id):
    """Remove um item da sacola"""
    if request.method == 'POST':
        sessao_id = request.session.session_key
        
        if sessao_id:
            try:
                item = get_object_or_404(ItemSacola, id=item_id, sessao_id=sessao_id)
                item.delete()
                
                total_itens = ItemSacola.objects.filter(sessao_id=sessao_id).count()
                
                return JsonResponse({
                    'status': 'success',
                    'message': 'Item removido da sacola!',
                    'total_itens': total_itens
                })
            except Exception as e:
                return JsonResponse({'status': 'error', 'message': str(e)})
    
    return JsonResponse({'status': 'error', 'message': 'Método não permitido'})

def atualizar_quantidade(request, item_id):
    """Atualiza a quantidade de um item na sacola"""
    if request.method == 'POST':
        sessao_id = request.session.session_key
        nova_quantidade = int(request.POST.get('quantidade', 1))
        
        if sessao_id and nova_quantidade > 0:
            item = get_object_or_404(ItemSacola, id=item_id, sessao_id=sessao_id)
            item.quantidade = nova_quantidade
            item.save()
            
            itens = ItemSacola.objects.filter(sessao_id=sessao_id)
            subtotal = sum(item.subtotal for item in itens)
            frete = Decimal('25.00') if subtotal > 0 else Decimal('0.00')
            total = subtotal + frete
            
            return JsonResponse({
                'status': 'success',
                'subtotal': float(subtotal),
                'frete': float(frete),
                'total': float(total),
                'item_subtotal': float(item.subtotal)
            })
    
    return JsonResponse({'status': 'error'})

def contador_sacola(request):
    """Retorna o número de itens na sacola para o contador do cabeçalho"""
    sessao_id = request.session.session_key
    if sessao_id:
        total = ItemSacola.objects.filter(sessao_id=sessao_id).count()
    else:
        total = 0
    return JsonResponse({'total_itens': total})

def totais_sacola(request):
    """Retorna os totais da sacola"""
    sessao_id = request.session.session_key
    if sessao_id:
        itens = ItemSacola.objects.filter(sessao_id=sessao_id)
        subtotal = sum(item.subtotal for item in itens)
        frete = Decimal('25.00') if subtotal > 0 else Decimal('0.00')
        total = subtotal + frete
    else:
        subtotal = frete = total = Decimal('0.00')
    
    return JsonResponse({
        'subtotal': float(subtotal),
        'frete': float(frete),
        'total': float(total)
    })

# ==================== CLIENTES / AUTENTICAÇÃO ====================

def cadastro(request):
    """Página de cadastro de cliente"""
    if request.method == 'POST':
        nome = request.POST.get('nome')
        telefone = request.POST.get('telefone')
        email = request.POST.get('email')
        senha = request.POST.get('senha')
        confirma_senha = request.POST.get('confirma_senha')
        
        # Validações
        if senha != confirma_senha:
            messages.error(request, 'As senhas não coincidem')
            return render(request, 'cadastro.html')
        
        if User.objects.filter(username=email).exists():
            messages.error(request, 'Este e-mail já está cadastrado')
            return render(request, 'cadastro.html')
        
        try:
            # Cria o usuário no sistema de autenticação do Django
            usuario = User.objects.create_user(
                username=email,
                email=email,
                password=senha,
                first_name=nome.split()[0] if nome else '',
                last_name=' '.join(nome.split()[1:]) if len(nome.split()) > 1 else ''
            )
            
            # Cria o perfil do cliente
            cliente = Cliente.objects.create(
                usuario=usuario,
                nome=nome,
                telefone=telefone,
                email=email
            )
            
            # Autentica e loga o usuário automaticamente
            user = authenticate(request, username=email, password=senha)
            if user:
                auth_login(request, user)
                messages.success(request, f'Cadastro realizado com sucesso! Bem-vindo, {nome}!')
                return redirect('index')
            else:
                messages.error(request, 'Erro ao fazer login automático')
                
        except Exception as e:
            messages.error(request, f'Erro ao cadastrar: {str(e)}')
            return render(request, 'cadastro.html')
    
    return render(request, 'cadastro.html')

def login_view(request):
    """Página de login"""
    if request.method == 'POST':
        email = request.POST.get('email')
        senha = request.POST.get('senha')
        
        user = authenticate(request, username=email, password=senha)
        
        if user is not None:
            auth_login(request, user)
            messages.success(request, f'Bem-vindo de volta, {user.first_name or user.username}!')
            return redirect('index')
        else:
            messages.error(request, 'E-mail ou senha inválidos')
            return render(request, 'login.html')
    
    return render(request, 'login.html')

def logout_view(request):
    """Faz logout do usuário"""
    logout(request)
    messages.success(request, 'Logout realizado com sucesso!')
    return redirect('index')

# ==================== PERFIL DO USUÁRIO ====================

@login_required
def perfil(request):
    """Página de perfil do usuário"""
    try:
        cliente = Cliente.objects.get(usuario=request.user)
    except Cliente.DoesNotExist:
        cliente = None
    
    return render(request, 'perfil.html', {'cliente': cliente})

@login_required
def atualizar_perfil(request):
    """Atualiza dados do perfil"""
    if request.method == 'POST':
        usuario = request.user
        usuario.first_name = request.POST.get('first_name', '')
        usuario.last_name = request.POST.get('last_name', '')
        usuario.save()
        
        # Atualiza telefone no modelo Cliente
        telefone = request.POST.get('telefone', '')
        if telefone:
            cliente, created = Cliente.objects.get_or_create(usuario=usuario)
            cliente.telefone = telefone
            cliente.nome = f"{usuario.first_name} {usuario.last_name}".strip()
            cliente.email = usuario.email
            cliente.save()
        
        messages.success(request, 'Perfil atualizado com sucesso!')
        return redirect('perfil')
    
    return redirect('perfil')

@login_required
def alterar_senha(request):
    """Altera a senha do usuário"""
    if request.method == 'POST':
        senha_atual = request.POST.get('senha_atual')
        nova_senha = request.POST.get('nova_senha')
        confirma_senha = request.POST.get('confirma_senha')
        
        usuario = request.user
        
        # Verifica se a senha atual está correta
        if not usuario.check_password(senha_atual):
            messages.error(request, 'Senha atual incorreta!')
            return redirect('perfil#alterar-senha')
        
        # Verifica se as novas senhas coincidem
        if nova_senha != confirma_senha:
            messages.error(request, 'As novas senhas não coincidem!')
            return redirect('perfil#alterar-senha')
        
        # Verifica tamanho mínimo da senha
        if len(nova_senha) < 6:
            messages.error(request, 'A senha deve ter pelo menos 6 caracteres!')
            return redirect('perfil#alterar-senha')
        
        # Altera a senha
        usuario.set_password(nova_senha)
        usuario.save()
        
        # Mantém o usuário logado após alterar a senha
        update_session_auth_hash(request, usuario)
        
        messages.success(request, 'Senha alterada com sucesso!')
        return redirect('perfil')
    
    return redirect('perfil')

# ==================== CHECKOUT ====================

@login_required
def checkout(request):
    """Página de checkout/finalização de compra"""
    sessao_id = request.session.session_key
    if not sessao_id:
        request.session.create()
        sessao_id = request.session.session_key
    
    itens = ItemSacola.objects.filter(sessao_id=sessao_id)
    
    if not itens.exists():
        messages.info(request, 'Sua sacola está vazia')
        return redirect('sacola')
    
    subtotal = sum(item.subtotal for item in itens)
    frete = Decimal('25.00')
    total = subtotal + frete
    
    # Pega dados do cliente
    cliente = None
    try:
        cliente = Cliente.objects.get(usuario=request.user)
    except Cliente.DoesNotExist:
        pass
    
    contexto = {
        'itens': itens,
        'subtotal': subtotal,
        'frete': frete,
        'total': total,
        'cliente': cliente,
    }
    
    return render(request, 'checkout.html', contexto)

def finalizar_pedido(request):
    """Processa o pedido e limpa a sacola"""
    if request.method == 'POST':
        sessao_id = request.session.session_key
        if sessao_id:
            ItemSacola.objects.filter(sessao_id=sessao_id).delete()
        
        messages.success(request, 'Pedido realizado com sucesso! Em breve você receberá um e-mail de confirmação.')
        return redirect('index')
    
    return redirect('checkout')

# ==================== UTILITÁRIOS ====================

def cadastrar_cliente(request):
    """Endpoint simples para cadastro (mantido para compatibilidade)"""
    return HttpResponse("Cadastro realizado com sucesso!")


#==================== BUSCA ======================

def busca(request):
    termo = request.GET.get('q', '')
    if termo:
        produtos = Produto.objects.filter(
            Q(nome__icontains=termo) | 
            Q(descricao__icontains=termo),
            disponivel=True
        )
    else:
        produtos = Produto.objects.filter(disponivel=True)[:6]
    
    return render(request, 'busca.html', {'produtos': produtos, 'termo': termo})