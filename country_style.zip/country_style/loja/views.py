from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from .models import Produto, Categoria, ItemSacola

def index(request):
    """Página inicial com produtos do banco de dados"""
    produtos = Produto.objects.filter(disponivel=True).order_by('-data_criacao')[:6]
    return render(request, 'index.html', {'produtos': produtos})

def cadastro(request):
    """Página de cadastro"""
    return render(request, 'cadastro.html')

def login(request):
    """Página de login"""
    return render(request, 'login.html')

def produto(request, produto_id):
    """Página de detalhe do produto"""
    produto = get_object_or_404(Produto, id=produto_id, disponivel=True)
    
    relacionados = Produto.objects.filter(
        categoria=produto.categoria, 
        disponivel=True
    ).exclude(id=produto.id)[:4]
    
    return render(request, 'produto.html', {
        'produto': produto,
        'relacionados': relacionados
    })

def sacola(request):
    sessao_id = request.session.session_key
    if not sessao_id:
        request.session.create()
        sessao_id = request.session.session_key
    
    # Isso deve trazer TODOS os itens da sessão
    itens = ItemSacola.objects.filter(sessao_id=sessao_id)
    
    from decimal import Decimal
    subtotal = sum(item.subtotal for item in itens)
    frete = Decimal('25.00') if subtotal > 0 else Decimal('0.00')
    total = subtotal + frete
    
    print(f"DEBUG - Itens encontrados: {itens.count()}")  # Linha de debug
    
    contexto = {
        'itens': itens,
        'subtotal': subtotal,
        'frete': frete,
        'total': total,
    }
    return render(request, 'sacola.html', contexto)

def adicionar_sacola(request, produto_id):
    """Adiciona um item à sacola via AJAX"""
    print("\n" + "="*50)
    print("FUNÇÃO ADICIONAR_SACOLA FOI CHAMADA!")
    print(f"Produto ID: {produto_id}")
    print(f"Método da requisição: {request.method}")
    print(f"Dados POST recebidos: {request.POST}")
    
    if request.method == 'POST':
        # Pega ou cria o ID da sessão
        sessao_id = request.session.session_key
        print(f"Sessão ID atual: {sessao_id}")
        
        if not sessao_id:
            request.session.create()
            sessao_id = request.session.session_key
            print(f"Nova sessão criada: {sessao_id}")
        
        try:
            # Busca o produto
            produto = get_object_or_404(Produto, id=produto_id, disponivel=True)
            print(f"Produto encontrado: {produto.nome}")
            
            # Pega os dados do POST
            tamanho = request.POST.get('tamanho', '')
            quantidade = int(request.POST.get('quantidade', 1))
            print(f"Tamanho recebido: '{tamanho}'")
            print(f"Quantidade recebida: {quantidade}")
            
            # Verifica se já existe este produto com mesmo tamanho na sacola
            item, created = ItemSacola.objects.get_or_create(
                produto=produto,
                sessao_id=sessao_id,
                tamanho=tamanho,
                defaults={'quantidade': quantidade}
            )
            
            print(f"Item existe? {not created}")
            print(f"Item ID: {item.id}")
            print(f"Quantidade atual: {item.quantidade}")
            
            # Se já existia, aumenta a quantidade
            if not created:
                item.quantidade += quantidade
                item.save()
                print(f"Quantidade atualizada para: {item.quantidade}")
            
            # Conta total de itens na sacola
            total_itens = ItemSacola.objects.filter(sessao_id=sessao_id).count()
            print(f"Total de itens na sacola agora: {total_itens}")
            
            # Lista todos os itens da sacola para debug
            print("Itens na sacola:")
            for i in ItemSacola.objects.filter(sessao_id=sessao_id):
                print(f"  - {i.produto.nome} (x{i.quantidade})")
            
            print("="*50 + "\n")
            
            return JsonResponse({
                'status': 'success',
                'message': 'Item adicionado à sacola!',
                'total_itens': total_itens
            })
            
        except Exception as e:
            print(f"ERRO NA VIEW: {str(e)}")
            print("="*50 + "\n")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            })
    
    print("Método não é POST!")
    print("="*50 + "\n")
    return JsonResponse({
        'status': 'error',
        'message': 'Método não permitido'
    })

def remover_sacola(request, item_id):
    """Remove um item da sacola"""
    if request.method == 'POST':
        sessao_id = request.session.session_key
        
        if sessao_id:
            try:
                item = get_object_or_404(ItemSacola, id=item_id, sessao_id=sessao_id)
                item.delete()
                
                # Conta total de itens restantes
                total_itens = ItemSacola.objects.filter(sessao_id=sessao_id).count()
                
                return JsonResponse({
                    'status': 'success',
                    'message': 'Item removido da sacola!',
                    'total_itens': total_itens
                })
            except Exception as e:
                return JsonResponse({
                    'status': 'error',
                    'message': str(e)
                })
    
    return JsonResponse({
        'status': 'error',
        'message': 'Método não permitido'
    })

def atualizar_quantidade(request, item_id):
    """Atualiza a quantidade de um item na sacola"""
    if request.method == 'POST':
        sessao_id = request.session.session_key
        nova_quantidade = int(request.POST.get('quantidade', 1))
        
        if sessao_id and nova_quantidade > 0:
            item = get_object_or_404(ItemSacola, id=item_id, sessao_id=sessao_id)
            item.quantidade = nova_quantidade
            item.save()
            
            # Recalcula os totais
            itens = ItemSacola.objects.filter(sessao_id=sessao_id)
            subtotal = sum(item.subtotal for item in itens)
            frete = 25.00 if subtotal > 0 else 0
            total = subtotal + frete
            
            return JsonResponse({
                'status': 'success',
                'subtotal': float(subtotal),
                'frete': float(frete),
                'total': float(total),
                'item_subtotal': float(item.subtotal)
            })
    
    return JsonResponse({'status': 'error'})

def cadastrar_cliente(request):
    """Processa o cadastro do cliente"""
    return HttpResponse("Cadastro realizado com sucesso!")

def produtos_por_categoria(request, categoria_slug):
    """Mostra produtos de uma categoria específica"""
    categoria = get_object_or_404(Categoria, slug=categoria_slug)
    produtos = Produto.objects.filter(categoria=categoria, disponivel=True)
    return render(request, 'categoria.html', {
        'categoria': categoria,
        'produtos': produtos
    })

def contador_sacola(request):
    """Retorna o número de itens na sacola para o contador do cabeçalho"""
    sessao_id = request.session.session_key
    if sessao_id:
        total = ItemSacola.objects.filter(sessao_id=sessao_id).count()
    else:
        total = 0
    return JsonResponse({'total_itens': total})

def totais_sacola(request):
    """Retorna os totais da sacola"""
    sessao_id = request.session.session_key
    from decimal import Decimal
    if sessao_id:
        itens = ItemSacola.objects.filter(sessao_id=sessao_id)
        subtotal = sum(item.subtotal for item in itens)
        frete = Decimal('25.00') if subtotal > 0 else Decimal('0.00')
        total = subtotal + frete
    else:
        subtotal = frete = total = Decimal('0.00')
    
    return JsonResponse({
        'subtotal': float(subtotal),  # Converte para float para JSON
        'frete': float(frete),
        'total': float(total)
    })