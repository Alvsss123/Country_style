// static/js/sacola.js

// Função para remover item da sacola (AGORA COM CONEXÃO COM O BANCO)
// Função para remover item da sacola (CORRIGIDA)

// Função para remover item da sacola (CORRIGIDA)
function removerItem(itemId) {
    if (confirm('Deseja remover este item da sacola?')) {
        const botao = event.target;
        const textoOriginal = botao.innerHTML;
        botao.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
        botao.disabled = true;
        
        // Pega o token CSRF
        const token = getCookie('csrftoken');
        
        fetch(`/remover-sacola/${itemId}/`, {
            method: 'POST',
            headers: {
                'X-CSRFToken': token,
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro na requisição');
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                // Remove o card do item
                const itemCard = document.getElementById(`item-${itemId}`);
                if (itemCard) {
                    itemCard.remove();
                }
                
                // Atualiza contador no cabeçalho
                if (window.atualizarContadorGlobal) {
                    window.atualizarContadorGlobal();
                }
                
                // Recalcula totais
                calcularTotais();
                
                // Se não houver mais itens, recarrega
                const itensRestantes = document.querySelectorAll('[id^="item-"]').length;
                if (itensRestantes === 0) {
                    location.reload();
                }
            } else {
                alert('Erro ao remover item: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Erro detalhado:', error);
            alert('Erro de conexão. Verifique o console (F12) para mais detalhes.');
        })
        .finally(() => {
            botao.innerHTML = textoOriginal;
            botao.disabled = false;
        });
    }
}

// Função para pegar o CSRF token (se não existir no contador.js)
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Função para finalizar compra
function finalizarCompra() {
    const itens = document.querySelectorAll('.col-md-8 .card-country').length;
    if (itens === 0) {
        alert('Sua sacola está vazia!');
        return;
    }
    window.location.href = '/checkout/';
}

// Função para continuar comprando
function continuarComprando() {
    window.location.href = '/';
}

// Função para atualizar o contador no cabeçalho (AGORA VIA SERVIDOR)
function atualizarContadorSacola() {
    fetch('/api/contador-sacola/')
        .then(response => response.json())
        .then(data => {
            const contador = document.getElementById('contador-sacola');
            if (contador) {
                contador.textContent = data.total_itens;
            }
        })
        .catch(error => console.error('Erro ao atualizar contador:', error));
}

// Função para calcular totais (ATUALIZADA PARA FUNCIONAR COM DADOS REAIS)
function calcularTotais() {
    // Em vez de calcular pelo HTML, busca do servidor
    fetch('/api/totais-sacola/')
        .then(response => response.json())
        .then(data => {
            // Atualiza subtotal
            const subtotalSpan = document.getElementById('subtotal');
            if (subtotalSpan) {
                subtotalSpan.textContent = `R$ ${data.subtotal.toFixed(2).replace('.', ',')}`;
            }
            
            // Atualiza frete
            const freteSpan = document.querySelector('.d-flex.justify-content-between span:last-child');
            if (freteSpan && freteSpan.closest('.d-flex').querySelector('span:first-child').textContent === 'Frete:') {
                freteSpan.textContent = `R$ ${data.frete.toFixed(2).replace('.', ',')}`;
            }
            
            // Atualiza total
            const totalSpan = document.getElementById('total');
            if (totalSpan) {
                totalSpan.textContent = `R$ ${data.total.toFixed(2).replace('.', ',')}`;
            }
        })
        .catch(error => console.error('Erro ao calcular totais:', error));
}

// Função para pegar o CSRF token (necessária para requisições POST)
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    return cookieValue;
}

// Executa quando a página carrega
document.addEventListener('DOMContentLoaded', function() {
    atualizarContadorSacola();
    calcularTotais();
});