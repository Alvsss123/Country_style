// static/js/contador.js

// Função para atualizar o contador em QUALQUER página
function atualizarContadorGlobal() {
    fetch('/api/contador-sacola/')
        .then(response => response.json())
        .then(data => {
            const contador = document.getElementById('contador-sacola');
            if (contador) {
                contador.textContent = data.total_itens;
            }
        })
        .catch(error => console.error('Erro ao atualizar contador:', error));
}

// Executa quando a página carrega
document.addEventListener('DOMContentLoaded', function() {
    atualizarContadorGlobal();
});

// Torna a função global para que outros scripts possam chamá-la
window.atualizarContadorGlobal = atualizarContadorGlobal;