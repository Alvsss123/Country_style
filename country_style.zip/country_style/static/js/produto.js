// ==================== PRODUTO.JS ====================
// Variável global para armazenar o tamanho selecionado
let tamanhoSelecionado = '';

// ==================== SELEÇÃO DE TAMANHO ====================
function selecionarTamanho(tamanho, botao) {
    tamanhoSelecionado = tamanho;
    
    // Remove a classe 'selecionado' de todos os botões de tamanho
    document.querySelectorAll('.tamanho-btn').forEach(btn => {
        btn.classList.remove('selecionado');
    });
    
    // Adiciona a classe 'selecionado' ao botão clicado
    botao.classList.add('selecionado');
    
    // ATUALIZA O TEXTO INFORMATIVO
    const infoDiv = document.getElementById('tamanho-selecionado-info');
    infoDiv.innerHTML = `✅ Tamanho selecionado: <strong>${tamanho}</strong>`;
    infoDiv.style.color = 'var(--verde-campo)';
    
    console.log('Tamanho selecionado:', tamanho); // Para teste
}

// ==================== CONTROLE DE QUANTIDADE ====================
function diminuirQuantidade() {
    let input = document.getElementById('quantidade');
    let display = document.getElementById('quantidade-valor');
    if (input.value > 1) {
        input.value = parseInt(input.value) - 1;
        display.textContent = input.value;
    }
}

function aumentarQuantidade() {
    let input = document.getElementById('quantidade');
    let display = document.getElementById('quantidade-valor');
    if (input.value < 10) {
        input.value = parseInt(input.value) + 1;
        display.textContent = input.value;
    } else {
        alert('Máximo de 10 unidades por produto');
    }
}

// ==================== AÇÕES DE COMPRA ====================

// Função para COMPRAR AGORA (redireciona para checkout)
function comprarAgora(produtoId) {
    // Verifica se usuário está logado
    const isAuthenticated = document.body.dataset.userAuthenticated === 'true';
    
    if (!isAuthenticated) {
        if (confirm('Você precisa estar logado para finalizar a compra. Deseja fazer login agora?')) {
            window.location.href = '/login/?next=' + encodeURIComponent(window.location.pathname);
        }
        return;
    }
    
    if (!tamanhoSelecionado) {
        alert('Por favor, selecione um tamanho');
        return;
    }
    
    const quantidade = document.getElementById('quantidade').value;
    
    // Mostra indicador de carregamento
    const botao = event.target;
    const textoOriginal = botao.innerHTML;
    botao.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processando...';
    botao.disabled = true;
    
    // Primeiro, adiciona o produto à sacola
    fetch(`/adicionar-sacola/${produtoId}/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: `tamanho=${encodeURIComponent(tamanhoSelecionado)}&quantidade=${quantidade}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Produto adicionado, agora redireciona para o checkout
            window.location.href = '/checkout/';
        } else {
            alert('Erro ao processar: ' + data.message);
            botao.innerHTML = textoOriginal;
            botao.disabled = false;
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('Erro de conexão. Tente novamente.');
        botao.innerHTML = textoOriginal;
        botao.disabled = false;
    });
}

// Função para ADICIONAR À SACOLA (apenas adiciona, não redireciona)
function adicionarSacola(produtoId) {
    if (!tamanhoSelecionado) {
        alert('Por favor, selecione um tamanho');
        return;
    }
    
    const quantidade = document.getElementById('quantidade').value;
    
    // Mostra indicador de carregamento
    const botao = event.target;
    const textoOriginal = botao.innerHTML;
    botao.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adicionando...';
    botao.disabled = true;
    
    // Envia para o servidor via AJAX
    fetch(`/adicionar-sacola/${produtoId}/`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: `tamanho=${encodeURIComponent(tamanhoSelecionado)}&quantidade=${quantidade}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Mostra mensagem de sucesso
            alert('✅ Produto adicionado à sacola!');
            
            // Atualiza o contador no cabeçalho
            if (window.atualizarContadorGlobal) {
                window.atualizarContadorGlobal();
            } else {
                // Fallback: atualiza direto
                const contador = document.getElementById('contador-sacola');
                if (contador) {
                    contador.textContent = data.total_itens;
                }
            }
        } else {
            alert('❌ Erro ao adicionar produto: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('❌ Erro de conexão. Tente novamente.');
    })
    .finally(() => {
        // Restaura o botão
        botao.innerHTML = textoOriginal;
        botao.disabled = false;
    });
}

// ==================== UTILITÁRIOS ====================

// Função para pegar o CSRF token
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    console.log('CSRF Token:', cookieValue);
    return cookieValue;
}