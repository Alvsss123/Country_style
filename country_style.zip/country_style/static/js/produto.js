
// Variável global para armazenar o tamanho selecionado
let tamanhoSelecionado = '';


function selecionarTamanho(tamanho, botao) {
    tamanhoSelecionado = tamanho;
    
    // Remove a classe 'selecionado' de todos os botões de tamanho
    document.querySelectorAll('.tamanho-btn').forEach(btn => {
        btn.classList.remove('selecionado');
    });
    
    // Adiciona a classe 'selecionado' ao botão clicado
    botao.classList.add('selecionado');
    
    // ATUALIZA O TEXTO INFORMATIVO
    const infoDiv = document.getElementById('tamanho-selecionado-info');
    infoDiv.innerHTML = `✅ Tamanho selecionado: <strong>${tamanho}</strong>`;
    infoDiv.style.color = 'var(--verde-campo)';
    
    console.log('Tamanho selecionado:', tamanho); // Para teste
}

function diminuirQuantidade() {
    let input = document.getElementById('quantidade');
    let display = document.getElementById('quantidade-valor');
    if (input.value > 1) {
        input.value = parseInt(input.value) - 1;
        display.textContent = input.value;
    }
}

function aumentarQuantidade() {
    let input = document.getElementById('quantidade');
    let display = document.getElementById('quantidade-valor');
    if (input.value < 10) {
        input.value = parseInt(input.value) + 1;
        display.textContent = input.value;
    } else {
        alert('Máximo de 10 unidades por produto');
    }
}

function comprarAgora(produtoId) {
    if (!tamanhoSelecionado) {
        alert('Por favor, selecione um tamanho');
        return;
    }
    const quantidade = document.getElementById('quantidade').value;
    alert(`Comprar agora:\nProduto: ${produtoId}\nTamanho: ${tamanhoSelecionado}\nQuantidade: ${quantidade}`);
    // window.location.href = `/checkout/?produto=${produtoId}&quantidade=${quantidade}&tamanho=${tamanhoSelecionado}`;
}

// Função para adicionar à sacola
function adicionarSacola(produtoId) {
    if (!tamanhoSelecionado) {
        alert('Por favor, selecione um tamanho');
        return;
    }
    
    const quantidade = document.getElementById('quantidade').value;
    
    // Mostra indicador de carregamento
    const botao = event.target;
    const textoOriginal = botao.innerHTML;
    botao.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Adicionando...';
    botao.disabled = true;
    
    // Envia para o servidor via AJAX
    fetch(`/adicionar-sacola/${produtoId}/`, {  // Mudei para URL relativa
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-CSRFToken': getCookie('csrftoken')
        },
        body: `tamanho=${encodeURIComponent(tamanhoSelecionado)}&quantidade=${quantidade}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            // Mostra mensagem de sucesso
            alert('✅ Produto adicionado à sacola!');
            
            // Atualiza o contador no cabeçalho usando a função global
            if (window.atualizarContadorGlobal) {
                window.atualizarContadorGlobal();
            } else {
                // Fallback: atualiza direto
                const contador = document.getElementById('contador-sacola');
                if (contador) {
                    contador.textContent = data.total_itens;
                }
            }
        } else {
            alert('❌ Erro ao adicionar produto: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        alert('❌ Erro de conexão. Tente novamente.');
    })
    .finally(() => {
        // Restaura o botão
        botao.innerHTML = textoOriginal;
        botao.disabled = false;
    });
}
// Função para pegar o CSRF token
function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            const cookie = cookies[i].trim();
            if (cookie.substring(0, name.length + 1) === (name + '=')) {
                cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                break;
            }
        }
    }
    console.log('CSRF Token:', cookieValue);
    return cookieValue;
}