// static/js/filtros.js

function filtrarCategoria(categoria) {
    if (categoria === 'todos') {
        window.location.href = '/';
    } else {
        window.location.href = `/categoria/${categoria}/`;
    }
}